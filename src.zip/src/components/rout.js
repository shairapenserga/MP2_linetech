import React from 'react'
import {Routes, Route } from 'react-router-dom';
import Home from './home';
import Shop from './shop';
import Nav from './nav';
import About from './about';

const Rout = () => {
return (
<>
<Nav/>
<Routes>
<Route path='/' element={<Home />}/> 
<Route path='/Shop' element={<Shop/> }/> 
<Route path='/About' element={<About/> }/> 
 
</Routes>
    
 </>
 );



}

export default Rout