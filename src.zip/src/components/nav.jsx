import React from 'react'
// import { FaBeer } from 'react-icons/fa';
 import './nav.css'
import logo from './images/logous.png';
 import {Link} from 'react-router-dom';
 import { AiOutlineSearch } from 'react-icons/ai';
import { CiHeart } from "react-icons/ci";
import { FaRegUser } from "react-icons/fa";
import { IoCartOutline } from "react-icons/io5";
// import { CiLogout, CiUser} from 'react-icons/ci';
const Nav = ({search, setSearch, searchproduct}) => {


return (
      <>

<nav className='navbar'>
    <div className='navbar-logo'>   
         <img src={logo} alt='logo'></img> 
        </div>
           <ul>
              <li><Link to='/' className='link'>Home</Link></li>
              <li><Link to='/shop' className='link'>Shop</Link></li>
              <li><Link to='/about' className='link'>About</Link></li>
              <li><Link to='/contact' className='link'>Contact</Link></li>
            </ul>  

     






            
            <div className='search_box'>
             <input type='text' value={search} placeholder='searh' onChange={(e) => setSearch(e.target.value)}/>
            <button onClick={searchproduct}><AiOutlineSearch /></button>
         </div>
         
         <div className='user'>
               <div className='icon'>
           <FaRegUser />
           <p>Sign In</p>
           <CiHeart />
           <IoCartOutline />
           </div>
          </div>
           </nav>
           
          
        
            </>
     )
 }

export default Nav;