import React  from 'react'
import './shop.css'
import banner from './images/Galaxy1.png'

const Shop = () =>  {
 return (
 <>

<div className="Shop">
            <div className="top_banner">
              <div className="container-hero">
                <div className="detail">
                
                 <h2>Shop</h2>  
                      
                 <p>lalalalalalalal</p> 
                 
                 
               </div>  
               <div className="img_box">      
               
              
             

               </div>   
               </div> 
               </div> 
               </div>







 <div className='shop'>
 <h2></h2>
 <p></p>
 <div className='container'>
 <div className='left_box'>
 <div className='category'>
 <div className='header'>
 <h3>all categories</h3>
 </div>
 <div className='box'>
                        <ul>
                            <li>All</li>
                            
                            <li>laptop</li>
                            <li>Mobile Phone</li>
                            <li>speaker</li>
                            <li>Accessories</li>
                            <li>headphone</li>
                           
                        </ul>
                    </div>
                    </div>
<div className='banner'>
<div className='img_box'>
<img src={banner} alt='leftbanner'></img>
</div>
 </div>    
 </div> 
 </div>
 </div>
 <div className='product_box'>
<h2></h2>
<div className='product_container'>
<div className='box'>
</div>
</div>
</div>

 </>
 )
}
export default Shop;