import React  from 'react'
import './about.css'
import logo from './images/JBL3.png'

import { Link } from 'react-router-dom'

const About = () =>  {
 return (
 <>
 <div className="About">
            <div className="top_banner">
              <div className="container-hero">
                <div className="detail">
                
                 <h2>About Us</h2>  
                      
                 <p>lalalalalalalal</p> 
                 
                 
               </div>  
               <div className="img_box">      
               
              
             

               </div>   
               </div> 
               </div> 
               </div>
 </>
 )
}
export default About;