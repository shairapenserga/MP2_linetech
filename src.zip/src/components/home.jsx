
import React, { useState } from 'react'

import logo from './images/JBL3.png'
 import mobile1 from './images/earbud1.png'
 import mobile2 from './images/earbud2.png'
 import mobile3 from './images/earbud3.png'
 import mobile4 from './images/earbud4.png'
import { FiTruck } from "react-icons/fi";
import { FaDollarSign } from "react-icons/fa";
import { HiOutlineReceiptPercent } from "react-icons/hi2";
import { TfiHeadphoneAlt } from "react-icons/tfi";
import { AiFillEye, AiFillHeart, AiOutlineShoppingCart} from "react-icons/ai";
// import leftbox from './images/Galaxy.png'   /* upper left  */
// import leftboxee from './images/Galaxy1.png' /* bottom left  */
// import middle from './images/center.png' /* upper middle  */
// import rightbox from './images/Galaxy.png'    /* upper right  */
// import rightbox1 from './images/center.png'   /* middle bigsize */ 
import Homeproduct from './home_product'
import './home.css';
import { Link } from 'react-router-dom'


const Home=() => {
   //Tranding Product
  const [trendingProduct, setTrendingProduct] = useState(Homeproduct)

    return (
        <>
        <div className="home">
            <div className="top_banner">
              <div className="container-hero">
                <div className="detail">
                <h3>True wireless gaming earbuds</h3>
                 <h2>JBL Quantum <br/>TWS Air </h2>  
                      
                 <p>30% off at your first order</p> 
                 <Link to='/shop' className="link">Shop Now</Link>
                 
               </div>  
               <div className="img_box">      
               
               <img src={logo} alt="item" className="earbuds"></img>
             

               </div>   
               </div> 
               </div> 
               </div>
               <div className='trending'>
          <div className='container'>
            <div className='left_box'>
              <div className='header'>
                <div className='heading'>
                <h2 onClick={() => allTrendingProduct ()}>trending product</h2>

                </div>
                <div className='cate'>
                  <h3 onClick={() => filtercate ('new')}>New</h3>
                  <h3 onClick={() => filtercate ('featured')}>Featured</h3>
                  <h3 onClick={() => filtercate ('top')}>top selling</h3>
                </div>
              </div>
              <div className='products'>
              <div className='container'>
              {
                    trendingProduct.map((curElm) => 
                    {
                        return(
                            <>
                         <div className='box'>
                          <div className='img_box'>
                            <img src={curElm.image} alt=''></img>
                            <div className='icon'>
                              <div className='icon_box'>
                                <AiFillEye />
                              </div>    
                              <div className='icon_box'>
                                <AiFillHeart />
                              </div>                        
                            </div>
                          </div>
                          <div className='info'>
                            <h3>{curElm.Name}</h3>
                            <p>${curElm.price}</p>
                            <button className='btn' onClick={() => addtocart (curElm)}>Add to cart</button>
                          </div>
                        </div>
                        </>
                      )
                    })
                  }
                </div>
              </div>
                </div>
                </div>
                </div>
                


             <div className="product_type">  
               <div className="container">
                <div className="box">
                    <div className="img_box">
                        <img src={mobile1} alt='mobile'></img>
                    </div>
                    <div className="detail" >
                        <p></p>
                    </div>
                </div>
                <div className="box"> 
                    <div className="img_box">
                    <img src={mobile2} alt='mobile'></img>
                    </div>
                    <div className="detail" >
                        <p></p>
                    </div>
                </div>
                <div className="box">
                    <div className="img_box">
                    <img src={mobile3} alt='mobile'></img>
                    </div>
                    <div className="detail" >
                        <p></p>
                    </div>
                </div>
                <div className="box">
                    <div className="img_box">
                    <img src={mobile4} alt='mobile'></img>
                    </div>
                    <div className="detail" >
                        <p></p>
                    </div>
                </div>
               </div>
            </div> 
            <div className="about">
                <div className="container">
                    <div className="box">
                        <div className="icon">
                        <FiTruck />
                        </div>
                       
                        <div className="detail">
                            <h3>Free Shipping</h3>
                            <p>Order above $1000</p>
                            </div>
                        </div>
                    
                    <div className="box">
                        <div className="icon">
                        <FaDollarSign />
                        </div>
                        <div className="detail">
                            <h3>Return & Refund</h3>
                            <p>Money Back Gaurantey</p>
                        </div>
                    </div>
                    <div className="box">
                        <div className="icon">
                        <HiOutlineReceiptPercent />
                        </div>
                        <div className="detail">
                            <h3>Member Discount</h3>
                            <p>On every Order</p>
                        </div>
                    </div>
                    <div className="box">
                        <div className="icon">
                        <TfiHeadphoneAlt />
                        </div>
                        <div className="detail">
                            <h3>Customer Support</h3>
                            <p>Every Time Call Support</p>
                        </div>
                    </div>
                </div>
            </div>



   {/* <div className='banners'>
                <div className='container'>


                   
                    <div className='left_box'>
                        <div className="box">
                            
                         <img src={leftbox} alt='banner'></img>
                         </div>
                    </div>


                   
                       <div className='right_box'>
                        <div className='top'>
                  <img src={middle} alt='banner'></img> 
                 
                  </div>
                    </div>


                  
                    <div className='right_box'>
                        <div className='top'>
                 <img src={rightbox} alt='banner'></img> 
                      
                    </div>
                    
                    </div> 
                    
                    </div>
                    </div>
                     
                   
                   
            
      <div className='content'>
                <div className='container'>
                    <div className="caption">
                        <h1>HELLO</h1>

                    </div>
                    </div>
                    </div>  */}









                    
    </>
    );
}

export default Home;