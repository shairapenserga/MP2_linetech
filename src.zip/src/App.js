import React from 'react'
import Nav from './components/nav'
// import Home from './components/home'
// import Shop from './components/shop';
import {BrowserRouter} from 'react-router-dom'
import Rout from './components/rout'
// import Shop from './components/shop'
// import Footer from './comp/footer'
// import Homeproduct from './comp/home_product'
const App = () => {
// const  [shop, setShop]
  return (
    <>
    <BrowserRouter>
    
   <Nav/>
   <Rout/>
    </BrowserRouter>
    </>
  )
}

export default App